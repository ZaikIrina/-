import java.util.ArrayList;

/**
 * Main class of the program
 */
public class Main {

    public static void main(String[] args) {

        try {

            ArrayList<ResultData> results = new ArrayList<>();

            results.add(Calculator.calculate(6,4));
            results.add(Calculator.calculate(8,5));

            Storage.save(results);

            ArrayList<ResultData> loaded = Storage.load();

            ViewFactory factory = new TextViewFactory();
            ResultView view = factory.createView();

            for(ResultData r : loaded){
                view.show(r);
            }

        } catch(Exception e){
            e.printStackTrace();
        }

    }
}
/**
 * Interface for displaying results
 */
public interface ResultView {

    void show(ResultData data);
}
/**
 * Class that performs calculations
 */
public class Calculator {

    public static ResultData calculate(double a, double h) {

        double b = Math.sqrt(h*h + Math.pow(a/2,2));

        double p1 = a + 2*b;

        double p2 = 2*(a+h);

        int sum = (int)(p1+p2);

        int count = 0;

        while(sum>0){
            if(sum%2==1) count++;
            sum/=2;
        }

        return new ResultData(a,h,count);
    }
}
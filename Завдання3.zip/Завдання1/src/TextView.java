/**
 * Text implementation for displaying results
 */
public class TextView implements ResultView {

    @Override
    public void show(ResultData data) {

        System.out.println("Base: " + data.a);
        System.out.println("Height: " + data.h);
        System.out.println("Number of ones in binary representation: " + data.ones);
        System.out.println("-------------------------");
    }
}
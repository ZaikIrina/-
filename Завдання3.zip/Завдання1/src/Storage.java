import java.io.*;
import java.util.ArrayList;

/**
 * Class for saving and loading a collection
 */
public class Storage {

    public static void save(ArrayList<ResultData> list) throws Exception {

        ObjectOutputStream out =
                new ObjectOutputStream(new FileOutputStream("results.ser"));

        out.writeObject(list);
        out.close();
    }

    public static ArrayList<ResultData> load() throws Exception {

        ObjectInputStream in =
                new ObjectInputStream(new FileInputStream("results.ser"));

        ArrayList<ResultData> list = (ArrayList<ResultData>) in.readObject();
        in.close();

        return list;
    }
}
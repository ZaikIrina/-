/**
 * Factory for creating text view objects
 */
public class TextViewFactory implements ViewFactory {

    @Override
    public ResultView createView() {
        return new TextView();
    }
}
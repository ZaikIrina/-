﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class BookingForm : Form
    {
        public BookingForm()
        {
            InitializeComponent();

            // Підключення кнопок
            btnAddBooking.Click += btnAddBooking_Click;
            btnDeleteBooking.Click += btnDeleteBooking_Click;
            btnBack.Click += btnBack_Click;
        }

        private void BookingForm_Load(object sender, EventArgs e)
        {
            UpdateBookingsTable();
        }

        // Оновлення таблиці бронювань
        private void UpdateBookingsTable()
        {
            dgvBookings.DataSource = null;
            dgvBookings.DataSource = Database.GetBookings();

            dgvBookings.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvBookings.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvBookings.ReadOnly = true;
            dgvBookings.AllowUserToAddRows = false;
            dgvBookings.RowHeadersVisible = false;

            if (dgvBookings.Columns.Contains("Id"))
                dgvBookings.Columns["Id"].HeaderText = "ID";

            if (dgvBookings.Columns.Contains("FullName"))
                dgvBookings.Columns["FullName"].HeaderText = "ПІБ користувача";

            if (dgvBookings.Columns.Contains("ParkingNumber"))
                dgvBookings.Columns["ParkingNumber"].HeaderText = "Місце";

            if (dgvBookings.Columns.Contains("BookingDate"))
                dgvBookings.Columns["BookingDate"].HeaderText = "Дата";

            if (dgvBookings.Columns.Contains("StartTime"))
                dgvBookings.Columns["StartTime"].HeaderText = "Початок";

            if (dgvBookings.Columns.Contains("EndTime"))
                dgvBookings.Columns["EndTime"].HeaderText = "Завершення";

            if (dgvBookings.Columns.Contains("Status"))
                dgvBookings.Columns["Status"].HeaderText = "Статус";
        }

        // Додавання бронювання
        private void btnAddBooking_Click(object sender, EventArgs e)
        {
            DataTable users = Database.GetUsers();
            DataTable parking = Database.GetParkingPlaces();

            if (users.Rows.Count == 0)
            {
                MessageBox.Show("Спочатку додайте користувачів!");
                return;
            }

            using (Form form = new Form())
            {
                form.Text = "Додавання бронювання";
                form.Size = new Size(430, 390);
                form.StartPosition = FormStartPosition.CenterParent;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.MaximizeBox = false;

                Label lblUser = new Label
                {
                    Text = "Користувач:",
                    Left = 20,
                    Top = 25,
                    Width = 120
                };

                ComboBox cmbUser = new ComboBox
                {
                    Left = 155,
                    Top = 20,
                    Width = 230,
                    DropDownStyle = ComboBoxStyle.DropDownList
                };

                DataTable userOptions = new DataTable();
                userOptions.Columns.Add("UserId", typeof(int));
                userOptions.Columns.Add("UserDisplay", typeof(string));

                foreach (DataRow row in users.Rows)
                {
                    userOptions.Rows.Add(
                        Convert.ToInt32(row["Id"]),
                        row["FullName"].ToString()
                    );
                }

                cmbUser.DataSource = userOptions;
                cmbUser.DisplayMember = "UserDisplay";
                cmbUser.ValueMember = "UserId";

                Label lblParking = new Label
                {
                    Text = "Паркувальне місце:",
                    Left = 20,
                    Top = 75,
                    Width = 130
                };

                ComboBox cmbParking = new ComboBox
                {
                    Left = 155,
                    Top = 70,
                    Width = 230,
                    DropDownStyle = ComboBoxStyle.DropDownList
                };

                DataTable parkingOptions = new DataTable();
                parkingOptions.Columns.Add("Number", typeof(int));
                parkingOptions.Columns.Add("DisplayText", typeof(string));

                foreach (DataRow row in parking.Rows)
                {
                    if (row["Status"].ToString() == "Вільне")
                    {
                        parkingOptions.Rows.Add(
                            Convert.ToInt32(row["Number"]),
                            "Місце №" + row["Number"] +
                            " (поверх " + row["Floor"] + ")"
                        );
                    }
                }

                if (parkingOptions.Rows.Count == 0)
                {
                    MessageBox.Show("Немає вільних паркувальних місць!");
                    return;
                }

                cmbParking.DataSource = parkingOptions;
                cmbParking.DisplayMember = "DisplayText";
                cmbParking.ValueMember = "Number";

                Label lblDate = new Label
                {
                    Text = "Дата бронювання:",
                    Left = 20,
                    Top = 125,
                    Width = 130
                };

                DateTimePicker dtpDate = new DateTimePicker
                {
                    Left = 155,
                    Top = 120,
                    Width = 230,
                    Format = DateTimePickerFormat.Short,
                    MinDate = DateTime.Today
                };

                Label lblStart = new Label
                {
                    Text = "Час початку:",
                    Left = 20,
                    Top = 175,
                    Width = 120
                };

                DateTimePicker dtpStart = new DateTimePicker
                {
                    Left = 155,
                    Top = 170,
                    Width = 230,
                    Format = DateTimePickerFormat.Time,
                    ShowUpDown = true
                };

                Label lblEnd = new Label
                {
                    Text = "Час завершення:",
                    Left = 20,
                    Top = 225,
                    Width = 130
                };

                DateTimePicker dtpEnd = new DateTimePicker
                {
                    Left = 155,
                    Top = 220,
                    Width = 230,
                    Format = DateTimePickerFormat.Time,
                    ShowUpDown = true
                };

                Button btnSave = new Button
                {
                    Text = "Зберегти",
                    Left = 155,
                    Top = 285,
                    Width = 110,
                    Height = 35,
                    DialogResult = DialogResult.None
                };

                btnSave.Click += (s, args) =>
                {
                    if (dtpStart.Value.TimeOfDay >=
                        dtpEnd.Value.TimeOfDay)
                    {
                        MessageBox.Show(
                            "Час завершення має бути пізніше часу початку!"
                        );
                        return;
                    }

                    form.DialogResult = DialogResult.OK;
                    form.Close();
                };

                form.Controls.Add(lblUser);
                form.Controls.Add(cmbUser);
                form.Controls.Add(lblParking);
                form.Controls.Add(cmbParking);
                form.Controls.Add(lblDate);
                form.Controls.Add(dtpDate);
                form.Controls.Add(lblStart);
                form.Controls.Add(dtpStart);
                form.Controls.Add(lblEnd);
                form.Controls.Add(dtpEnd);
                form.Controls.Add(btnSave);

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        int userId = Convert.ToInt32(cmbUser.SelectedValue);
                        int parkingNumber =
                            Convert.ToInt32(cmbParking.SelectedValue);

                        Database.AddBooking(
                            userId,
                            parkingNumber,
                            dtpDate.Value.ToString("yyyy-MM-dd"),
                            dtpStart.Value.ToString("HH:mm"),
                            dtpEnd.Value.ToString("HH:mm")
                        );

                        UpdateBookingsTable();

                        MessageBox.Show(
                            "Бронювання успішно додано!",
                            "Успіх",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Помилка: " + ex.Message);
                    }
                }
            }
        }

        // Видалення бронювання
        private void btnDeleteBooking_Click(object sender, EventArgs e)
        {
            if (dgvBookings.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть бронювання для видалення!");
                return;
            }

            int id = Convert.ToInt32(
                dgvBookings.SelectedRows[0].Cells["Id"].Value
            );

            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете видалити це бронювання?",
                "Підтвердження",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    Database.DeleteBooking(id);
                    UpdateBookingsTable();

                    MessageBox.Show("Бронювання видалено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка: " + ex.Message);
                }
            }
        }

        // Повернення назад
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

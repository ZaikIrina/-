﻿
using System;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class ReportsForm : Form
    {
        public ReportsForm()
        {
            InitializeComponent();

            btnRefresh.Click += btnRefresh_Click;
            btnBack.Click += btnBack_Click;

            UpdateReport();
        }

        // Оновлення звіту
        private void UpdateReport()
        {
            lblTotal.Text =
                "Усього місць: " + Database.GetTotalParkingPlaces();

            lblFree.Text =
                "Вільні місця: " + Database.GetFreeParkingPlaces();

            lblBooked.Text =
                "Заброньовані місця: " + Database.GetBookedParkingPlaces();

            lblUsers.Text =
                "Користувачі: " + Database.GetTotalUsers();
        }

        // Завантаження форми
        private void ReportsForm_Load(object sender, EventArgs e)
        {
            UpdateReport();
        }

        // Кнопка оновлення звіту
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            UpdateReport();

            MessageBox.Show(
                "Звіт успішно оновлено!",
                "Звіти",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        // Кнопка назад
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

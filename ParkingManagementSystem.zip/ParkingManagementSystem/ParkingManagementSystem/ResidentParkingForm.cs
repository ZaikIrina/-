﻿
using System;
using System.Data;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class ResidentParkingForm : Form
    {
        private DataGridView dgvParking;
        private Button btnBack;
        private Label lblTitle;

        public ResidentParkingForm()
        {
            InitializeComponent();

            this.Text = "Паркувальні місця";
            this.Size = new System.Drawing.Size(950, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.FromArgb(240, 244, 248);

            lblTitle = new Label();
            lblTitle.Text = "Паркувальні місця";
            lblTitle.Location = new System.Drawing.Point(200, 30);
            lblTitle.Size = new System.Drawing.Size(550, 50);
            lblTitle.Font = new System.Drawing.Font("Segoe UI", 20, System.Drawing.FontStyle.Bold);
            lblTitle.ForeColor = System.Drawing.Color.FromArgb(40, 55, 75);
            lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            dgvParking = new DataGridView();
            dgvParking.Location = new System.Drawing.Point(50, 110);
            dgvParking.Size = new System.Drawing.Size(830, 350);
            dgvParking.ReadOnly = true;
            dgvParking.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvParking.AllowUserToAddRows = false;
            dgvParking.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            btnBack = new Button();
            btnBack.Text = "Назад";
            btnBack.Location = new System.Drawing.Point(350, 490);
            btnBack.Size = new System.Drawing.Size(250, 50);
            btnBack.Font = new System.Drawing.Font("Segoe UI", 12, System.Drawing.FontStyle.Bold);
            btnBack.BackColor = System.Drawing.Color.FromArgb(127, 140, 141);
            btnBack.ForeColor = System.Drawing.Color.White;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.Click += btnBack_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(dgvParking);
            this.Controls.Add(btnBack);

            LoadParkingPlaces();
        }

        private void LoadParkingPlaces()
        {
            dgvParking.DataSource = Database.GetParkingPlaces();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResidentParkingForm_Load(object sender, EventArgs e)
        {
        }
    }
}

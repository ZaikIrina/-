﻿
using System;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class ResidentForm : Form
    {
        private int residentId;

        public ResidentForm()
        {
            InitializeComponent();
        }

        public ResidentForm(int userId)
        {
            InitializeComponent();
            residentId = userId;
        }

        private void ResidentForm_Load(object sender, EventArgs e)
        {
        }

        private void btnParking_Click(object sender, EventArgs e)
        {
            ResidentParkingForm form = new ResidentParkingForm();
            form.ShowDialog();
        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            ResidentBookingsForm form = new ResidentBookingsForm(residentId);
            form.ShowDialog();
        }

        private void btnNewBooking_Click(object sender, EventArgs e)
        {
            ResidentNewBookingForm form = new ResidentNewBookingForm(residentId);
            form.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете вийти з програми?",
                "Вихід",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

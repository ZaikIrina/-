﻿
using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;

namespace ParkingManagementSystem
{
    public partial class ResidentBookingsForm : Form
    {
        private int residentId;
        private DataGridView dgvBookings;
        private Button btnCancel;
        private Button btnBack;
        private Label lblTitle;

        public ResidentBookingsForm(int userId)
        {
            InitializeComponent();

            residentId = userId;

            this.Text = "Мої бронювання";
            this.Size = new Size(950, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 244, 248);

            lblTitle = new Label();
            lblTitle.Text = "Мої бронювання";
            lblTitle.Location = new Point(200, 30);
            lblTitle.Size = new Size(550, 50);
            lblTitle.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(40, 55, 75);
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            dgvBookings = new DataGridView();
            dgvBookings.Location = new Point(50, 110);
            dgvBookings.Size = new Size(830, 330);
            dgvBookings.ReadOnly = true;
            dgvBookings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBookings.AllowUserToAddRows = false;
            dgvBookings.MultiSelect = false;
            dgvBookings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            btnCancel = new Button();
            btnCancel.Text = "Скасувати бронювання";
            btnCancel.Location = new Point(180, 470);
            btnCancel.Size = new Size(250, 50);
            btnCancel.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btnCancel.BackColor = Color.FromArgb(231, 76, 60);
            btnCancel.ForeColor = Color.White;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.Click += btnCancel_Click;

            btnBack = new Button();
            btnBack.Text = "Назад";
            btnBack.Location = new Point(500, 470);
            btnBack.Size = new Size(250, 50);
            btnBack.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnBack.BackColor = Color.FromArgb(127, 140, 141);
            btnBack.ForeColor = Color.White;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.Click += btnBack_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(dgvBookings);
            this.Controls.Add(btnCancel);
            this.Controls.Add(btnBack);

            LoadBookings();
        }

        private void LoadBookings()
        {
            DataTable table = Database.GetBookings();

            table.DefaultView.RowFilter = "UserId = " + residentId;

            dgvBookings.DataSource = table.DefaultView;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (dgvBookings.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть бронювання!");
                return;
            }

            int bookingId = Convert.ToInt32(
                dgvBookings.SelectedRows[0].Cells["Id"].Value
            );

            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете скасувати це бронювання?",
                "Скасування бронювання",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                Database.DeleteResidentBooking(bookingId, residentId);
                LoadBookings();

                MessageBox.Show("Бронювання скасовано!");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ResidentBookingsForm_Load(object sender, EventArgs e)
        {
        }
    }
}

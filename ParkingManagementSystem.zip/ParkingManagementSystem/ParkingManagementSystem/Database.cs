﻿
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;

namespace ParkingManagementSystem
{
    public class Database
    {
        private static string dbPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "parking.db");

        private static string connectionString =
            "Data Source=" + dbPath + ";Version=3;";

        // Створення бази даних і таблиць
        public static void Initialize()
        {
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
            }

            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql = @"
                    CREATE TABLE IF NOT EXISTS ParkingPlaces
                    (
                        Number INTEGER PRIMARY KEY,
                        Floor INTEGER NOT NULL,
                        Status TEXT NOT NULL
                    );

                    CREATE TABLE IF NOT EXISTS Users
                    (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        FullName TEXT NOT NULL,
                        Apartment TEXT NOT NULL,
                        Phone TEXT NOT NULL,
                        CarNumber TEXT NOT NULL
                    );

                    CREATE TABLE IF NOT EXISTS Bookings
                    (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        UserId INTEGER NOT NULL,
                        ParkingNumber INTEGER NOT NULL,
                        BookingDate TEXT NOT NULL,
                        StartTime TEXT NOT NULL,
                        EndTime TEXT NOT NULL,
                        Status TEXT NOT NULL
                    );";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                }
                // Додавання полів авторизації для мешканців
                EnsureColumnExists(connection, "Users", "Login");
                EnsureColumnExists(connection, "Users", "Password");
            }
        }

        // Отримання паркувальних місць
        public static DataTable GetParkingPlaces()
        {
            DataTable table = new DataTable();

            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql =
                    "SELECT Number, Floor, Status FROM ParkingPlaces";

                using (SQLiteDataAdapter adapter =
                    new SQLiteDataAdapter(sql, connection))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        // Додавання паркувального місця
        public static void AddParkingPlace(
            int number, int floor, string status)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql = @"
                    INSERT INTO ParkingPlaces
                    (Number, Floor, Status)
                    VALUES
                    (@number, @floor, @status);";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@number", number);
                    command.Parameters.AddWithValue("@floor", floor);
                    command.Parameters.AddWithValue("@status", status);

                    command.ExecuteNonQuery();
                }
            }
        }

        // Видалення паркувального місця
        public static void DeleteParkingPlace(int number)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql =
                    "DELETE FROM ParkingPlaces WHERE Number = @number";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@number", number);
                    command.ExecuteNonQuery();
                }
            }
        }

        // Зміна номера паркувального місця
        public static void UpdateParkingPlaceNumber(int oldNumber, int newNumber)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteTransaction transaction =
                    connection.BeginTransaction())
                {
                    // Перевірка, чи існує новий номер
                    string checkSql = @"
                SELECT COUNT(*) FROM ParkingPlaces
                WHERE Number = @newNumber";

                    using (SQLiteCommand command =
                        new SQLiteCommand(checkSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@newNumber", newNumber);

                        int count = Convert.ToInt32(command.ExecuteScalar());

                        if (count > 0)
                            throw new Exception("Місце з таким номером уже існує!");
                    }

                    // Зміна номера паркувального місця
                    string updateParkingSql = @"
                UPDATE ParkingPlaces
                SET Number = @newNumber
                WHERE Number = @oldNumber";

                    using (SQLiteCommand command =
                        new SQLiteCommand(updateParkingSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@newNumber", newNumber);
                        command.Parameters.AddWithValue("@oldNumber", oldNumber);

                        int affected = command.ExecuteNonQuery();

                        if (affected == 0)
                            throw new Exception("Паркувальне місце не знайдено!");
                    }

                    // Оновлення номера у бронюваннях
                    string updateBookingsSql = @"
                UPDATE Bookings
                SET ParkingNumber = @newNumber
                WHERE ParkingNumber = @oldNumber";

                    using (SQLiteCommand command =
                        new SQLiteCommand(updateBookingsSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@newNumber", newNumber);
                        command.Parameters.AddWithValue("@oldNumber", oldNumber);

                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
            }
        }

        // Отримання всіх користувачів
        public static DataTable GetUsers()
        {
            DataTable table = new DataTable();

            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql = @"
                    SELECT Id, FullName, Apartment, Phone, CarNumber
                    FROM Users";

                using (SQLiteDataAdapter adapter =
                    new SQLiteDataAdapter(sql, connection))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        // Додавання користувача

        public static void AddUser(
            string fullName,
            string apartment,
            string phone,
            string carNumber,
            string login,
            string password)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string checkSql =
                    "SELECT COUNT(*) FROM Users WHERE Login = @login";

                using (SQLiteCommand checkCommand =
                    new SQLiteCommand(checkSql, connection))
                {
                    checkCommand.Parameters.AddWithValue("@login", login);

                    int count = Convert.ToInt32(
                        checkCommand.ExecuteScalar());

                    if (count > 0)
                        throw new Exception("Такий логін уже використовується!");
                }

                string sql = @"
            INSERT INTO Users
            (FullName, Apartment, Phone, CarNumber, Login, Password)
            VALUES
            (@name, @apartment, @phone, @carNumber, @login, @password)";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@name", fullName);
                    command.Parameters.AddWithValue("@apartment", apartment);
                    command.Parameters.AddWithValue("@phone", phone);
                    command.Parameters.AddWithValue("@carNumber", carNumber);
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);

                    command.ExecuteNonQuery();
                }
            }
        }


        // Видалення користувача
        public static void DeleteUser(int id)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql =
                    "DELETE FROM Users WHERE Id = @id";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    command.ExecuteNonQuery();
                }
            }
        }


        // Отримання всіх бронювань
        public static DataTable GetBookings()
        {
            DataTable table = new DataTable();

            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT
                Bookings.Id,
                Bookings.UserId,
                Users.FullName,
                Bookings.ParkingNumber,
                Bookings.BookingDate,
                Bookings.StartTime,
                Bookings.EndTime,
                Bookings.Status
            FROM Bookings
            LEFT JOIN Users ON Bookings.UserId = Users.Id
            ORDER BY Bookings.BookingDate, Bookings.StartTime";

                using (SQLiteDataAdapter adapter =
                    new SQLiteDataAdapter(sql, connection))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }


        // Додавання бронювання
        public static void AddBooking(
            int userId, int parkingNumber,
            string bookingDate, string startTime, string endTime)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteTransaction transaction =
                    connection.BeginTransaction())
                {
                    string checkSql = @"
                        SELECT Status FROM ParkingPlaces
                        WHERE Number = @number";

                    string parkingStatus;

                    using (SQLiteCommand checkCommand =
                        new SQLiteCommand(checkSql, connection, transaction))
                    {
                        checkCommand.Parameters.AddWithValue(
                            "@number", parkingNumber);

                        object result = checkCommand.ExecuteScalar();

                        if (result == null)
                            throw new Exception("Паркувальне місце не знайдено!");

                        parkingStatus = result.ToString();
                    }

                    if (parkingStatus != "Вільне")
                        throw new Exception(
                            "Це паркувальне місце вже зайняте або заброньоване!");

                    string insertSql = @"
                        INSERT INTO Bookings
                        (UserId, ParkingNumber, BookingDate,
                         StartTime, EndTime, Status)
                        VALUES
                        (@userId, @number, @date,
                         @start, @end, 'Активне')";

                    using (SQLiteCommand command =
                        new SQLiteCommand(insertSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@number", parkingNumber);
                        command.Parameters.AddWithValue("@date", bookingDate);
                        command.Parameters.AddWithValue("@start", startTime);
                        command.Parameters.AddWithValue("@end", endTime);

                        command.ExecuteNonQuery();
                    }

                    string updateSql = @"
                        UPDATE ParkingPlaces
                        SET Status = 'Заброньоване'
                        WHERE Number = @number";

                    using (SQLiteCommand command =
                        new SQLiteCommand(updateSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@number", parkingNumber);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
            }
        }

        // Видалення бронювання
        public static void DeleteBooking(int id)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteTransaction transaction =
                    connection.BeginTransaction())
                {
                    string getNumberSql = @"
                        SELECT ParkingNumber FROM Bookings
                        WHERE Id = @id";

                    object result;

                    using (SQLiteCommand command =
                        new SQLiteCommand(getNumberSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        result = command.ExecuteScalar();
                    }

                    if (result == null)
                        throw new Exception("Бронювання не знайдено!");

                    int parkingNumber = Convert.ToInt32(result);

                    string deleteSql =
                        "DELETE FROM Bookings WHERE Id = @id";

                    using (SQLiteCommand command =
                        new SQLiteCommand(deleteSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }

                    string updateSql = @"
                        UPDATE ParkingPlaces
                        SET Status = 'Вільне'
                        WHERE Number = @number
                        AND Status = 'Заброньоване'
                        AND NOT EXISTS
                        (
                            SELECT 1 FROM Bookings
                            WHERE ParkingNumber = @number
                            AND Status = 'Активне'
                        )";

                    using (SQLiteCommand command =
                        new SQLiteCommand(updateSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@number", parkingNumber);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
            }
        }

        // Скасування бронювання конкретним мешканцем
        public static void DeleteResidentBooking(int id, int userId)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteTransaction transaction =
                    connection.BeginTransaction())
                {
                    string getNumberSql = @"
                SELECT ParkingNumber
                FROM Bookings
                WHERE Id = @id AND UserId = @userId";

                    object result;

                    using (SQLiteCommand command =
                        new SQLiteCommand(getNumberSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.Parameters.AddWithValue("@userId", userId);

                        result = command.ExecuteScalar();
                    }

                    if (result == null)
                        throw new Exception("Бронювання не знайдено або воно вам не належить!");

                    int parkingNumber = Convert.ToInt32(result);

                    string deleteSql = @"
                DELETE FROM Bookings
                WHERE Id = @id AND UserId = @userId";

                    using (SQLiteCommand command =
                        new SQLiteCommand(deleteSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.Parameters.AddWithValue("@userId", userId);

                        command.ExecuteNonQuery();
                    }

                    string updateSql = @"
                UPDATE ParkingPlaces
                SET Status = 'Вільне'
                WHERE Number = @number
                AND Status = 'Заброньоване'
                AND NOT EXISTS
                (
                    SELECT 1 FROM Bookings
                    WHERE ParkingNumber = @number
                    AND Status = 'Активне'
                )";

                    using (SQLiteCommand command =
                        new SQLiteCommand(updateSql, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@number", parkingNumber);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
            }
        }


        // Кількість усіх паркувальних місць
        public static int GetTotalParkingPlaces()
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command =
                    new SQLiteCommand(
                        "SELECT COUNT(*) FROM ParkingPlaces", connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        // Кількість вільних місць
        public static int GetFreeParkingPlaces()
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command =
                    new SQLiteCommand(
                        "SELECT COUNT(*) FROM ParkingPlaces WHERE Status = 'Вільне'",
                        connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        // Кількість заброньованих місць
        public static int GetBookedParkingPlaces()
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command =
                    new SQLiteCommand(
                        "SELECT COUNT(*) FROM ParkingPlaces WHERE Status = 'Заброньоване'",
                        connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        // Загальна кількість користувачів
        public static int GetTotalUsers()
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (SQLiteCommand command =
                    new SQLiteCommand(
                        "SELECT COUNT(*) FROM Users", connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }
        // Перевірка та додавання стовпців у таблицю
        private static void EnsureColumnExists(
            SQLiteConnection connection, string tableName, string columnName)
        {
            bool exists = false;

            using (SQLiteCommand command = new SQLiteCommand(
                "PRAGMA table_info(" + tableName + ")", connection))
            using (SQLiteDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (reader["name"].ToString() == columnName)
                    {
                        exists = true;
                        break;
                    }
                }
            }

            if (!exists)
            {
                string sql = "ALTER TABLE " + tableName +
                             " ADD COLUMN " + columnName + " TEXT";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        // Авторизація мешканця
        public static int LoginResident(string login, string password)
        {
            using (SQLiteConnection connection =
                new SQLiteConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT Id FROM Users
            WHERE Login = @login AND Password = @password";

                using (SQLiteCommand command =
                    new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);

                    object result = command.ExecuteScalar();

                    if (result != null)
                        return Convert.ToInt32(result);

                    return 0;
                }
            }
        }
    }
}

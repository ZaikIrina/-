﻿
using System;
using System.Data;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class UsersForm : Form
    {
        public UsersForm()
        {
            InitializeComponent();
            UpdateUsersTable();
        }

        // Оновлення таблиці користувачів
        private void UpdateUsersTable()
        {
            dgvUsers.DataSource = null;
            dgvUsers.DataSource = Database.GetUsers();

            dgvUsers.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvUsers.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvUsers.ReadOnly = true;
            dgvUsers.AllowUserToAddRows = false;

            if (dgvUsers.Columns.Contains("Id"))
                dgvUsers.Columns["Id"].HeaderText = "ID";

            if (dgvUsers.Columns.Contains("FullName"))
                dgvUsers.Columns["FullName"].HeaderText = "ПІБ";

            if (dgvUsers.Columns.Contains("Apartment"))
                dgvUsers.Columns["Apartment"].HeaderText = "Квартира";

            if (dgvUsers.Columns.Contains("Phone"))
                dgvUsers.Columns["Phone"].HeaderText = "Телефон";

            if (dgvUsers.Columns.Contains("CarNumber"))
                dgvUsers.Columns["CarNumber"].HeaderText = "Номер автомобіля";
        }

        // Додавання користувача
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            using (Form form = new Form())
            {
                form.Text = "Додавання користувача";
                form.Size = new System.Drawing.Size(420, 440);
                form.StartPosition = FormStartPosition.CenterParent;

                Label[] labels =
                {
                    new Label { Text = "ПІБ:", Left = 20, Top = 20, Width = 125 },
                    new Label { Text = "Номер квартири:", Left = 20, Top = 65, Width = 125 },
                    new Label { Text = "Телефон:", Left = 20, Top = 110, Width = 125 },
                    new Label { Text = "Номер автомобіля:", Left = 20, Top = 155, Width = 130 },
                    new Label { Text = "Логін:", Left = 20, Top = 200, Width = 125 },
                    new Label { Text = "Пароль:", Left = 20, Top = 245, Width = 125 }
                };

                TextBox[] fields = new TextBox[6];

                for (int i = 0; i < 6; i++)
                {
                    form.Controls.Add(labels[i]);

                    fields[i] = new TextBox
                    {
                        Left = 155,
                        Top = 20 + i * 45,
                        Width = 220
                    };

                    if (i == 5)
                        fields[i].UseSystemPasswordChar = true;

                    form.Controls.Add(fields[i]);
                }

                Button btnSave = new Button
                {
                    Text = "Зберегти",
                    Left = 145,
                    Top = 315,
                    Width = 120,
                    Height = 35,
                    DialogResult = DialogResult.OK
                };

                form.Controls.Add(btnSave);
                form.AcceptButton = btnSave;

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    string fullName = fields[0].Text.Trim();
                    string apartment = fields[1].Text.Trim();
                    string phone = fields[2].Text.Trim();
                    string carNumber = fields[3].Text.Trim();
                    string login = fields[4].Text.Trim();
                    string password = fields[5].Text;

                    if (string.IsNullOrWhiteSpace(fullName) ||
                        string.IsNullOrWhiteSpace(apartment) ||
                        string.IsNullOrWhiteSpace(phone) ||
                        string.IsNullOrWhiteSpace(carNumber) ||
                        string.IsNullOrWhiteSpace(login) ||
                        string.IsNullOrWhiteSpace(password))
                    {
                        MessageBox.Show("Заповніть усі поля!");
                        return;
                    }

                    try
                    {
                        Database.AddUser(
                            fullName,
                            apartment,
                            phone,
                            carNumber,
                            login,
                            password
                        );

                        UpdateUsersTable();

                        MessageBox.Show("Користувача успішно додано!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Не вдалося додати користувача: " + ex.Message,
                            "Помилка",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }
        }

        // Видалення користувача
        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть користувача для видалення!");
                return;
            }

            int id = Convert.ToInt32(
                dgvUsers.SelectedRows[0].Cells["Id"].Value);

            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете видалити користувача?",
                "Підтвердження",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Database.DeleteUser(id);
                UpdateUsersTable();

                MessageBox.Show("Користувача видалено!");
            }
        }

        // Повернення назад
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UsersForm_Load(object sender, EventArgs e)
        {
            UpdateUsersTable();
        }
    }
}

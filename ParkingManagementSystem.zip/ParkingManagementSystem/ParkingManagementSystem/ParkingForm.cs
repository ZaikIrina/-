﻿
using System;
using System.Data;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class ParkingForm : Form
    {
        public ParkingForm()
        {
            InitializeComponent();

            // Якщо база порожня, додаємо початкові місця
            if (Database.GetParkingPlaces().Rows.Count == 0)
            {
                Database.AddParkingPlace(1, 1, "Вільне");
                Database.AddParkingPlace(2, 1, "Зайняте");
                Database.AddParkingPlace(3, 2, "Вільне");
                Database.AddParkingPlace(4, 2, "Заброньоване");
            }

            UpdateParkingTable();
        }

        // Оновлення таблиці паркувальних місць
        private void UpdateParkingTable()
        {
            dgvParking.DataSource = Database.GetParkingPlaces();

            dgvParking.Columns["Number"].HeaderText = "Номер місця";
            dgvParking.Columns["Floor"].HeaderText = "Поверх";
            dgvParking.Columns["Status"].HeaderText = "Статус";
        }

        // Завантаження форми
        private void ParkingForm_Load(object sender, EventArgs e)
        {
            UpdateParkingTable();
        }

        // Додавання паркувального місця
        private void btnAddParking_Click(object sender, EventArgs e)
        {
            DataTable table = Database.GetParkingPlaces();

            int newNumber = 1;

            foreach (DataRow row in table.Rows)
            {
                int number = Convert.ToInt32(row["Number"]);

                if (number >= newNumber)
                {
                    newNumber = number + 1;
                }
            }

            try
            {
                Database.AddParkingPlace(
                    newNumber,
                    1,
                    "Вільне"
                );

                UpdateParkingTable();

                MessageBox.Show(
                    "Паркувальне місце додано!",
                    "Успіх",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
        }

        // Видалення паркувального місця
        private void btnDeleteParking_Click(object sender, EventArgs e)
        {
            if (dgvParking.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть місце для видалення!");
                return;
            }

            int number = Convert.ToInt32(
                dgvParking.SelectedRows[0].Cells["Number"].Value
            );

            DialogResult result = MessageBox.Show(
                "Ви дійсно хочете видалити це паркувальне місце?",
                "Підтвердження",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    Database.DeleteParkingPlace(number);

                    UpdateParkingTable();

                    MessageBox.Show("Паркувальне місце видалено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Помилка: " + ex.Message);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditParking_Click(object sender, EventArgs e)
        {

            if (dgvParking.SelectedRows.Count == 0)
            {
                MessageBox.Show("Оберіть паркувальне місце для редагування!");
                return;
            }

            int oldNumber = Convert.ToInt32(
                dgvParking.SelectedRows[0].Cells["Number"].Value
            );

            using (Form form = new Form())
            {
                form.Text = "Зміна номера паркувального місця";
                form.Size = new System.Drawing.Size(350, 180);
                form.StartPosition = FormStartPosition.CenterParent;

                Label label = new Label
                {
                    Text = "Новий номер:",
                    Left = 20,
                    Top = 25,
                    Width = 110
                };

                NumericUpDown numeric = new NumericUpDown
                {
                    Left = 140,
                    Top = 22,
                    Width = 150,
                    Minimum = 1,
                    Maximum = 9999,
                    Value = oldNumber
                };

                Button btnSave = new Button
                {
                    Text = "Зберегти",
                    Left = 110,
                    Top = 75,
                    Width = 120,
                    DialogResult = DialogResult.OK
                };

                form.Controls.Add(label);
                form.Controls.Add(numeric);
                form.Controls.Add(btnSave);
                form.AcceptButton = btnSave;

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    int newNumber = (int)numeric.Value;

                    if (newNumber == oldNumber)
                    {
                        MessageBox.Show("Новий номер збігається зі старим!");
                        return;
                    }

                    try
                    {
                        Database.UpdateParkingPlaceNumber(oldNumber, newNumber);

                        UpdateParkingTable();

                        MessageBox.Show(
                            "Номер паркувального місця успішно змінено!",
                            "Успіх",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Помилка: " + ex.Message,
                            "Помилка",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
            }

        }
    }
}

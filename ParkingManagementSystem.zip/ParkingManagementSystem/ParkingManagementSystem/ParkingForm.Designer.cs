﻿namespace ParkingManagementSystem
{
    partial class ParkingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblParkingTitle = new System.Windows.Forms.Label();
            this.dgvParking = new System.Windows.Forms.DataGridView();
            this.btnAddParking = new System.Windows.Forms.Button();
            this.btnDeleteParking = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnEditParking = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParking)).BeginInit();
            this.SuspendLayout();
            // 
            // lblParkingTitle
            // 
            this.lblParkingTitle.AutoSize = true;
            this.lblParkingTitle.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblParkingTitle.Location = new System.Drawing.Point(326, 24);
            this.lblParkingTitle.Name = "lblParkingTitle";
            this.lblParkingTitle.Size = new System.Drawing.Size(318, 38);
            this.lblParkingTitle.TabIndex = 0;
            this.lblParkingTitle.Text = "ПАРКУВАЛЬНІ МІСЦЯ";
            // 
            // dgvParking
            // 
            this.dgvParking.AllowUserToAddRows = false;
            this.dgvParking.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvParking.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParking.Location = new System.Drawing.Point(40, 120);
            this.dgvParking.Name = "dgvParking";
            this.dgvParking.ReadOnly = true;
            this.dgvParking.RowHeadersWidth = 51;
            this.dgvParking.RowTemplate.Height = 24;
            this.dgvParking.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvParking.Size = new System.Drawing.Size(850, 350);
            this.dgvParking.TabIndex = 1;
            // 
            // btnAddParking
            // 
            this.btnAddParking.Location = new System.Drawing.Point(40, 511);
            this.btnAddParking.Name = "btnAddParking";
            this.btnAddParking.Size = new System.Drawing.Size(160, 45);
            this.btnAddParking.TabIndex = 2;
            this.btnAddParking.Text = "Додати місце";
            this.btnAddParking.UseVisualStyleBackColor = true;
            this.btnAddParking.Click += new System.EventHandler(this.btnAddParking_Click);
            // 
            // btnDeleteParking
            // 
            this.btnDeleteParking.Location = new System.Drawing.Point(268, 511);
            this.btnDeleteParking.Name = "btnDeleteParking";
            this.btnDeleteParking.Size = new System.Drawing.Size(160, 45);
            this.btnDeleteParking.TabIndex = 3;
            this.btnDeleteParking.Text = "Видалити місце";
            this.btnDeleteParking.UseVisualStyleBackColor = true;
            this.btnDeleteParking.Click += new System.EventHandler(this.btnDeleteParking_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(730, 511);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(160, 45);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnEditParking
            // 
            this.btnEditParking.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEditParking.Location = new System.Drawing.Point(492, 511);
            this.btnEditParking.Name = "btnEditParking";
            this.btnEditParking.Size = new System.Drawing.Size(180, 45);
            this.btnEditParking.TabIndex = 5;
            this.btnEditParking.Text = "Змінити номер";
            this.btnEditParking.UseVisualStyleBackColor = true;
            this.btnEditParking.Click += new System.EventHandler(this.btnEditParking_Click);
            // 
            // ParkingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 603);
            this.Controls.Add(this.btnEditParking);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnDeleteParking);
            this.Controls.Add(this.btnAddParking);
            this.Controls.Add(this.dgvParking);
            this.Controls.Add(this.lblParkingTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ParkingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Паркувальні місця";
            this.Load += new System.EventHandler(this.ParkingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvParking)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblParkingTitle;
        private System.Windows.Forms.DataGridView dgvParking;
        private System.Windows.Forms.Button btnAddParking;
        private System.Windows.Forms.Button btnDeleteParking;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnEditParking;
    }
}
﻿
using System;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            // Вхід адміністратора
            if (login == "admin" && password == "admin123")
            {
                AdminForm adminForm = new AdminForm();
                adminForm.Show();
                this.Hide();
                return;
            }

            // Поки що перевіряємо мешканця через базу даних
            int userId = Database.LoginResident(login, password);

            if (userId > 0)
            {
                ResidentForm residentForm = new ResidentForm(userId);
                residentForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(
                    "Неправильний логін або пароль!",
                    "Помилка авторизації",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}

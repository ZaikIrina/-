﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ParkingManagementSystem
{
    public partial class ResidentNewBookingForm : Form
    {
        private int residentId;

        private ComboBox cmbParking;
        private DateTimePicker dtpDate;
        private DateTimePicker dtpStart;
        private DateTimePicker dtpEnd;
        private Button btnBook;
        private Button btnBack;
        private Label lblTitle;

        public ResidentNewBookingForm(int userId)
        {
            InitializeComponent();

            residentId = userId;

            this.Text = "Забронювати місце";
            this.Size = new Size(700, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 244, 248);

            lblTitle = new Label();
            lblTitle.Text = "Бронювання паркувального місця";
            lblTitle.Location = new Point(50, 30);
            lblTitle.Size = new Size(580, 50);
            lblTitle.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(40, 55, 75);
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            Label lblParking = new Label();
            lblParking.Text = "Паркувальне місце:";
            lblParking.Location = new Point(100, 120);
            lblParking.Size = new Size(200, 30);
            lblParking.Font = new Font("Segoe UI", 11);

            cmbParking = new ComboBox();
            cmbParking.Location = new Point(310, 120);
            cmbParking.Size = new Size(250, 30);
            cmbParking.Font = new Font("Segoe UI", 11);
            cmbParking.DropDownStyle = ComboBoxStyle.DropDownList;

            Label lblDate = new Label();
            lblDate.Text = "Дата бронювання:";
            lblDate.Location = new Point(100, 190);
            lblDate.Size = new Size(200, 30);
            lblDate.Font = new Font("Segoe UI", 11);

            dtpDate = new DateTimePicker();
            dtpDate.Location = new Point(310, 190);
            dtpDate.Size = new Size(250, 30);
            dtpDate.Format = DateTimePickerFormat.Short;
            dtpDate.MinDate = DateTime.Today;

            Label lblStart = new Label();
            lblStart.Text = "Час початку:";
            lblStart.Location = new Point(100, 260);
            lblStart.Size = new Size(200, 30);
            lblStart.Font = new Font("Segoe UI", 11);

            dtpStart = new DateTimePicker();
            dtpStart.Location = new Point(310, 260);
            dtpStart.Size = new Size(250, 30);
            dtpStart.Format = DateTimePickerFormat.Time;
            dtpStart.ShowUpDown = true;

            Label lblEnd = new Label();
            lblEnd.Text = "Час завершення:";
            lblEnd.Location = new Point(100, 330);
            lblEnd.Size = new Size(200, 30);
            lblEnd.Font = new Font("Segoe UI", 11);

            dtpEnd = new DateTimePicker();
            dtpEnd.Location = new Point(310, 330);
            dtpEnd.Size = new Size(250, 30);
            dtpEnd.Format = DateTimePickerFormat.Time;
            dtpEnd.ShowUpDown = true;

            btnBook = new Button();
            btnBook.Text = "Забронювати";
            btnBook.Location = new Point(100, 430);
            btnBook.Size = new Size(220, 50);
            btnBook.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnBook.BackColor = Color.FromArgb(52, 152, 219);
            btnBook.ForeColor = Color.White;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Click += btnBook_Click;

            btnBack = new Button();
            btnBack.Text = "Назад";
            btnBack.Location = new Point(360, 430);
            btnBack.Size = new Size(220, 50);
            btnBack.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnBack.BackColor = Color.FromArgb(127, 140, 141);
            btnBack.ForeColor = Color.White;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.Click += btnBack_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblParking);
            this.Controls.Add(cmbParking);
            this.Controls.Add(lblDate);
            this.Controls.Add(dtpDate);
            this.Controls.Add(lblStart);
            this.Controls.Add(dtpStart);
            this.Controls.Add(lblEnd);
            this.Controls.Add(dtpEnd);
            this.Controls.Add(btnBook);
            this.Controls.Add(btnBack);

            LoadParkingPlaces();
        }

        private void LoadParkingPlaces()
        {
            DataTable table = Database.GetParkingPlaces();

            DataView view = new DataView(table);
            view.RowFilter = "Status = 'Вільне'";

            cmbParking.DataSource = view;
            cmbParking.DisplayMember = "Number";
            cmbParking.ValueMember = "Number";
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            if (cmbParking.SelectedValue == null)
            {
                MessageBox.Show("Немає вільних паркувальних місць!");
                return;
            }

            if (dtpEnd.Value.TimeOfDay <= dtpStart.Value.TimeOfDay)
            {
                MessageBox.Show("Час завершення має бути пізніше часу початку!");
                return;
            }

            if (dtpDate.Value.Date == DateTime.Today &&
                dtpStart.Value.TimeOfDay <= DateTime.Now.TimeOfDay)
            {
                MessageBox.Show("Час початку бронювання має бути в майбутньому!");
                return;
            }

            try
            {
                int parkingNumber = Convert.ToInt32(cmbParking.SelectedValue);

                Database.AddBooking(
                    residentId,
                    parkingNumber,
                    dtpDate.Value.ToString("yyyy-MM-dd"),
                    dtpStart.Value.ToString("HH:mm"),
                    dtpEnd.Value.ToString("HH:mm")
                );

                MessageBox.Show(
                    "Бронювання успішно створено!",
                    "Бронювання",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                LoadParkingPlaces();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не вдалося створити бронювання: " + ex.Message,
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                LoadParkingPlaces();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ResidentNewBookingForm_Load(object sender, EventArgs e)
        {
        }
    }
}

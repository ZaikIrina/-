import java.util.ArrayList;
import java.util.List;

/**
 * Macro command (group of commands)
 */
public class MacroCommand implements Command {

    private List<Command> commands = new ArrayList<>();

    public void add(Command c) {
        commands.add(c);
    }

    @Override
    public void execute() {
        for(Command c : commands) {
            c.execute();
        }
    }

    @Override
    public void undo() {
        for(int i = commands.size()-1; i >=0; i--) {
            commands.get(i).undo();
        }
    }
}
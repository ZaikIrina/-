import java.util.Scanner;

/**
 * Main class with dialog
 */
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        CommandManager manager = CommandManager.getInstance();

        while(true) {

            System.out.println("1 - Calculate");
            System.out.println("2 - Undo");
            System.out.println("3 - Macro demo");
            System.out.println("4 - Test");
            System.out.println("0 - Exit");

            int choice = sc.nextInt();

            if(choice == 0) break;

            switch(choice) {

                case 1:
                    System.out.print("Enter a: ");
                    double a = sc.nextDouble();

                    System.out.print("Enter h: ");
                    double h = sc.nextDouble();

                    manager.executeCommand(new CalculateCommand(a,h));
                    break;

                case 2:
                    manager.undo();
                    break;

                case 3:
                    MacroCommand macro = new MacroCommand();

                    macro.add(new CalculateCommand(5,3));
                    macro.add(new CalculateCommand(7,2));

                    manager.executeCommand(macro);
                    break;

                case 4:
                    Tester.runTest();
                    break;
            }
        }

        sc.close();
    }
}
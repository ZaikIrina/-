/**
 * Performs calculations
 */
public class Calculator {

    public static ResultData calculate(double a, double h) {

        double b = Math.sqrt(h*h + Math.pow(a/2,2));
        double p1 = a + 2*b;
        double p2 = 2*(a+h);

        int sum = (int)(p1+p2);

        return new ResultData(a,h,Integer.bitCount(sum));
    }
}
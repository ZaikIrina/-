/**
 * Command for calculation
 */
public class CalculateCommand implements Command {

    private double a, h;
    private ResultData result;

    /**
     * Constructor
     */
    public CalculateCommand(double a, double h) {
        this.a = a;
        this.h = h;
    }

    @Override
    public void execute() {
        result = Calculator.calculate(a,h);
        System.out.println("Result: " + result.ones);
    }

    @Override
    public void undo() {
        System.out.println("Calculation undone");
        result = null;
    }
}
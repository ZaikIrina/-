import java.io.Serializable;

/**
 * Data class
 */
public class ResultData implements Serializable {

    public double a;
    public double h;
    public int ones;

    public ResultData(double a, double h, int ones) {
        this.a = a;
        this.h = h;
        this.ones = ones;
    }
}
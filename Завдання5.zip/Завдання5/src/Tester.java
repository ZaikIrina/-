/**
 * Test class
 */
public class Tester {

    public static void runTest() {

        CommandManager manager = CommandManager.getInstance();

        manager.executeCommand(new CalculateCommand(6,4));
        manager.executeCommand(new CalculateCommand(8,5));

        manager.undo();
    }
}
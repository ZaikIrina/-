import java.util.Stack;

/**
 * Singleton class for managing commands
 */
public class CommandManager {

    private static CommandManager instance;

    private Stack<Command> history = new Stack<>();

    private CommandManager(){}

    /**
     * Get instance
     */
    public static CommandManager getInstance() {

        if(instance == null)
            instance = new CommandManager();

        return instance;
    }

    /**
     * Execute command
     */
    public void executeCommand(Command c) {
        c.execute();
        history.push(c);
    }

    /**
     * Undo last command
     */
    public void undo() {

        if(!history.isEmpty()) {
            history.pop().undo();
        } else {
            System.out.println("Nothing to undo");
        }
    }
}
import java.io.*;

/**
 * Демонстрація серіалізації та десеріалізації.
 */
public class classserialization {

    /**
     * Збереження об'єкта у файл
     */
    public static void save(classdate data) throws Exception {
        ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("data.ser"));
        out.writeObject(data);
        out.close();
    }

    /**
     * Завантаження об'єкта з файлу
     */
    public static classdate load() throws Exception {
        ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("data.ser"));
        classdate data = (classdate) in.readObject();
        in.close();
        return data;
    }
}

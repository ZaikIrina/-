/**
 * Клас для обчислення площі.
 * Використовує агрегування класу RectangleData.
 */
public class classcalculator {

    /** агрегування */
    private classdate data;

    /**
     * Конструктор
     */
    public classcalculator(classdate data) {
        this.data = data;
    }

    /**
     * Обчислення площі
     */
    public void calculateArea() {
        data.area = data.width * data.height;
    }
}
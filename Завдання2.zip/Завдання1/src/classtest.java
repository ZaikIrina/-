/**
 * Клас для тестування програми.
 */
public class classtest {

    public static void main(String[] args) {

        try {

            // створення даних
            classdate data = new classdate(5, 4);

            // обчислення
            classcalculator calc = new classcalculator(data);
            calc.calculateArea();

            System.out.println("Area before save: " + data.area);
            System.out.println("Transient field: " + data.tempInfo);

            // серіалізація
            classserialization.save(data);

            // десеріалізація
            classdate loaded = classserialization.load();

            System.out.println("Area after load: " + loaded.area);
            System.out.println("Transient after load: " + loaded.tempInfo);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

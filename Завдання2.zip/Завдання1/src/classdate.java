import java.io.Serializable;

/**
 * Клас для зберігання параметрів та результатів обчислення.
 * Реалізує інтерфейс Serializable для можливості серіалізації.
 */
public class classdate implements Serializable {

    /** ширина прямокутника */
    public double width;

    /** висота прямокутника */
    public double height;

    /** результат обчислення площі */
    public double area;

    /**
     * transient поле не буде серіалізоване
     */
    public transient String tempInfo;

    /**
     * Конструктор
     */
    public classdate(double width, double height) {
        this.width = width;
        this.height = height;
        this.tempInfo = "Temporary information";
    }
}
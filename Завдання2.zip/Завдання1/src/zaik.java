import java.io.Serializable;

/**
 * Клас для зберігання параметрів та результатів
 */
class Data implements Serializable {

    public double a;
    public double h;
    public int ones;

    transient String info;

    public Data(double a, double h) {
        this.a = a;
        this.h = h;
        info = "temporary";
    }
}

/**
 * Клас обчислень
 */
class Calculator {

    private Data data;

    public Calculator(Data data) {
        this.data = data;
    }

    public void calculate() {

        double b = Math.sqrt(data.h * data.h + Math.pow(data.a / 2, 2));

        double p1 = data.a + 2 * b;

        double p2 = 2 * (data.a + data.h);

        int sum = (int)(p1 + p2);

        int count = 0;

        while (sum > 0) {
            if (sum % 2 == 1)
                count++;
            sum /= 2;
        }

        data.ones = count;
    }
}

/**
 * Головний клас
 */
public class zaik {

    public static void main(String[] args) {

        Data data = new Data(6, 4);

        Calculator calc = new Calculator(data);

        calc.calculate();

        System.out.println("Кількість 1 у двійковому записі: " + data.ones);
    }
}